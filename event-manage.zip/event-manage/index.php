<?php

// Plugin Name: Event Management
// Plugin URI: https://codewp.ai
// Description: A plugin for event management.
// Author: CodeWP Assistant
// Author URI: https://codewp.ai
// Version: 1.0

// Enqueue CSS styles for the form
function event_management_enqueue_styles() {
    wp_enqueue_style( 'event-management-styles', plugin_dir_url( __FILE__ ) . 'css/styles.css' );
}
function event_management_enqueue_scripts() {
    wp_enqueue_script( 'submit-form', plugin_dir_url( __FILE__ ) . 'js/submit-form.js', array( 'jquery' ), '1.0', true );

    wp_localize_script( 'submit-form', 'ajax_object', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
}
add_action( 'wp_enqueue_scripts', 'event_management_enqueue_scripts' );

// Create a custom database table for event submissions
function event_management_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'event_submissions';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id INT(11) NOT NULL AUTO_INCREMENT,
        event_name VARCHAR(255) NOT NULL,
        event_date DATE NOT NULL,
        event_description TEXT NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}
register_activation_hook( __FILE__, 'event_management_create_table' );

// Display the form using a shortcode
function event_management_form_shortcode() {
    ob_start();
    ?>
    <form id="event-management-form" method="post">
        <label for="event-name">Event Name:</label>
        <input type="text" name="event_name" id="event-name" required>
        <label for="event-date">Event Date:</label>
        <input type="date" name="event_date" id="event-date" required>
        <label for="event-description">Event Description:</label>
        <textarea name="event_description" id="event-description" required></textarea>
        <input type="submit" value="Submit">
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode( 'event_management_form', 'event_management_form_shortcode' );

// Handle form submission
function event_management_form_submission() {
    if ( isset( $_POST['event_name'] ) && isset( $_POST['event_date'] ) && isset( $_POST['event_description'] ) ) {
        $event_name = sanitize_text_field( $_POST['event_name'] );
        $event_date = sanitize_text_field( $_POST['event_date'] );
        $event_description = sanitize_textarea_field( $_POST['event_description'] );

        global $wpdb;
        $table_name = $wpdb->prefix . 'event_submissions';
        $existing_event = $wpdb->get_row(
    $wpdb->prepare(
        "SELECT * FROM $table_name WHERE event_name = %s AND event_date = %s AND event_description = %s",
        $event_name,
        $event_date,
        $event_description
    )
);

if ( ! $existing_event ) {
    $wpdb->insert(
        $table_name,
        array(
            'event_name' => $event_name,
            'event_date' => $event_date,
            'event_description' => $event_description
        )
    );

    wp_send_json_success( 'Event submitted successfully' );
} else {
    wp_send_json_error( 'Duplicate event found. Event not submitted.' );
}

        wp_send_json_success( 'Event submitted successfully' );
    } else {
        wp_send_json_error( 'Error submitting event' );
    }
}
add_action( 'wp_ajax_event_management_form_submission', 'event_management_form_submission' );
add_action( 'wp_ajax_nopriv_event_management_form_submission', 'event_management_form_submission' );

// Create admin page for event submissions
function event_management_admin_page() {
    add_menu_page(
        'Event Management',
        'Event Management',
        'manage_options',
        'event-management',
        'event_management_admin_page_callback',
        'dashicons-calendar',
        20
    );
}
add_action( 'admin_menu', 'event_management_admin_page' );

// Callback function for the admin page
function event_management_admin_page_callback() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'event_submissions';
    $events = $wpdb->get_results( "SELECT * FROM $table_name" );
    ?>
    <div class="wrap">
        <h1>Event Submissions</h1>
        <table class="wp-list-table widefat striped">
            <thead>
                <tr>
                    <th>Event Name</th>
                    <th>Event Date</th>
                    <th>Event Description</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $events as $event ) : ?>
                    <tr>
                        <td><?php echo esc_html( $event->event_name ); ?></td>
                        <td><?php echo esc_html( $event->event_date ); ?></td>
                        <td><?php echo esc_html( $event->event_description ); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}