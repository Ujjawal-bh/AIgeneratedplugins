// Function to handle form submission
function submitForm(event) {
  // Prevent the default form submission
  event.preventDefault();

  // Get the form element
  var form = document.getElementById('auto-detailer-form');

  // Perform frontend validation
  if (!validateForm(form)) {
    return;
  }

  // Create a new FormData object
  var formData = new FormData(form);

  // Perform backend validation
  if (!validateFormData(formData)) {
    return;
  }

  // Send the form data via AJAX
  var xhr = new XMLHttpRequest();
  xhr.open('POST', 'https://example.com/submit-form');
  xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
  xhr.onload = function() {
    if (xhr.status === 200) {
      // Form submission successful
      alert('Form submitted successfully!');
      form.reset();
    } else {
      // Form submission failed
      alert('Form submission failed. Please try again later.');
    }
  };
  xhr.send(formData);
}

// Function to perform frontend validation
function validateForm(form) {
  // Add your validation logic here
  return true;
}

// Function to perform backend validation
function validateFormData(formData) {
  // Add your validation logic here
  return true;
}

// Attach the submitForm function to the form submit event
document.getElementById('auto-detailer-form').addEventListener('submit', submitForm);