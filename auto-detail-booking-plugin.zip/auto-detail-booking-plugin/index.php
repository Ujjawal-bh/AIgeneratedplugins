<?php
/**
 * Plugin Name: Auto Detailer Form
 * Plugin URI: https://codewp.ai
 * Description: A form for an auto detailer with frontend and backend validation.
 * Version: 1.0.0
 * Author: CodeWP Assistant
 * Author URI: https://codewp.ai
 * License: GPL2+
 * Text Domain: codewp
 */

// Create custom database table for form submissions
function create_custom_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'auto_bookings';

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        message TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";

    $wpdb->query($sql);
}
register_activation_hook( __FILE__, 'create_custom_table' );

// Enqueue scripts and styles
function enqueue_form_scripts() {
    wp_enqueue_script( 'jquery' );
    wp_enqueue_script( 'form-script', plugin_dir_url( __FILE__ ) . 'form-script.js', array('jquery'), '1.0', true );
    wp_enqueue_style( 'form-style', plugin_dir_url( __FILE__ ) . 'form-style.css' );
    wp_enqueue_style( 'admin-styles', admin_url( 'css/wp-admin.css' ) );
}
add_action( 'wp_enqueue_scripts', 'enqueue_form_scripts' );

// Create shortcode for form
function auto_detailer_form_shortcode() {
    ob_start();
    ?>
    <form id="auto-detailer-form" class="auto-detailer-form" method="post">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone:</label>
            <input type="tel" name="phone" id="phone" required>
        </div>
        <div class="form-group">
            <label for="message">Message:</label>
            <textarea name="message" id="message" rows="5"></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="submit-button">Submit</button>
        </div>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode( 'auto_detailer_form', 'auto_detailer_form_shortcode' );

// Backend validation and saving form submissions
function save_auto_booking() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'auto_bookings';

    $name    = sanitize_text_field( $_POST['name'] );
    $email   = sanitize_email( $_POST['email'] );
    $phone   = sanitize_text_field( $_POST['phone'] );
    $message = sanitize_textarea_field( $_POST['message'] );

    // Perform backend validation
    if ( ! $name || ! $email || ! $phone ) {
        wp_send_json_error( 'Please fill in all required fields.' );
    }

    // Insert form submission into database
    $wpdb->insert(
        $table_name,
        array(
            'name'    => $name,
            'email'   => $email,
            'phone'   => $phone,
            'message' => $message,
        )
    );

    wp_send_json_success( 'Form submitted successfully.' );
}
add_action( 'wp_ajax_save_auto_booking', 'save_auto_booking' );
add_action( 'wp_ajax_nopriv_save_auto_booking', 'save_auto_booking' );

// Create admin menu and display form submissions
function auto_bookings_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'auto_bookings';

    $submissions = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY created_at DESC" );
    ?>
    <div class="wrap">
        <h1>Auto Bookings</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Message</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $submissions as $submission ) : ?>
                    <tr>
                        <td><?php echo $submission->id; ?></td>
                        <td><?php echo $submission->name; ?></td>
                        <td><?php echo $submission->email; ?></td>
                        <td><?php echo $submission->phone; ?></td>
                        <td><?php echo $submission->message; ?></td>
                        <td><?php echo $submission->created_at; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}
function add_auto_bookings_page() {
    add_menu_page( 'Auto Bookings', 'Auto Bookings', 'manage_options', 'auto-bookings', 'auto_bookings_page' );
}
add_action( 'admin_menu', 'add_auto_bookings_page' );